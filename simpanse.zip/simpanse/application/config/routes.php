<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "login";
$route['404_override'] = 'error';


/*********** USER DEFINED ROUTES *******************/

$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['logout'] = 'user/logout';

$route['userListing'] = 'user/userListing';
$route['List_atmListing'] = 'List_atm/List_atmListing';
$route['List_atm_historyListing'] = 'List_atm_history/List_atm_historyListing';
$route['List_atm_history_detailsListing'] = 'List_atm_history_details/List_atm_history_detailsListing';
$route['List_laporanListing'] = 'List_laporan/List_laporanListing';
$route['List_laporan_cmListing'] = 'List_laporan_cm/List_laporan_cmListing';
$route['List_laporan_cm_detailsListing'] = 'List_laporan_cm_details/List_laporan_cm_detailsListing';
$route['List_laporan_cm_historyListing'] = 'List_laporan_cm_history/List_laporan_cm_historyListing';
$route['List_laporan_pmListing'] = 'List_laporan_pm/List_laporan_pmListing';

$route['ReportListing'] = 'Report/ReportListing';
$route['aboutListing'] = 'about/aboutListing';

$route['userListing/(:num)'] = "user/userListing/$1";
$route['List_atmListing/(:num)'] = "List_atm/List_atmListing/$1";
$route['List_atm_historyListing/(:num)'] = "List_atm_history/List_atm_historyListing/$1";
$route['List_atm_history_detailsListing/(:num)'] = "List_atm_history_details/List_atm_history_detailsListing/$1";
$route['List_laporanListing/(:num)'] = "List_laporan/List_laporanListing/$1";
$route['List_laporan_cmListing/(:num)'] = "List_laporan_cm/List_laporan_cmListing/$1";
$route['List_laporan_cm_detailsListing/(:num)'] = "List_laporan_cm_details/List_laporan_cm_detailsListing/$1";
$route['List_laporan_cm_historyListing/(:num)'] = "List_laporan_cm_history/List_laporan_cm_historyListing/$1";
$route['List_laporan_pmListing/(:num)'] = "List_laporan_pm/List_laporan_pmListing/$1";

$route['addNew'] = "user/addNew";
$route['addNewUser'] = "user/addNewUser";

$route['addNew1'] = "List_atm/addNew1";

$route['addNew3a'] = "List_laporan/addNew3a";
$route['addNew3b'] = "List_laporan/addNew3b";
$route['addNew3c'] = "List_laporan/addNew3c";
$route['addNew3d'] = "List_laporan/addNew3d";
$route['addNew3e'] = "List_laporan/addNew3e";
$route['addNew4a'] = "List_laporan_cm/addNew4a";
$route['addNew4b'] = "List_laporan_cm/addNew4b";
$route['addNew4c'] = "List_laporan_cm/addNew4c";
$route['addNew4d'] = "List_laporan_cm/addNew4d";


$route['upload'] = "List_atm/upload";
$route['formList_atm'] = "List_atm/formList_atm";
$route['upload_List_laporan_pm'] = "List_laporan_pm/upload_List_laporan_pm";
$route['formList_laporan_pm'] = "List_laporan_pm/formList_laporan_pm";

$route['clearList_atm'] = "List_atm/clearList_atm";
$route['clearList_laporan_pm'] = "List_laporan_pm/clearList_laporan_pm";

$route['addNewList_atm'] = "List_atm/addNewList_atm";
$route['approved_status_atr'] = "List_atm_history/approved_status_atr";
$route['rejected_status_atr'] = "List_atm_history/rejected_status_atr";
$route['approved_status_selesai'] = "List_atm_history/approved_status_selesai";
$route['rejected_status_selesai'] = "List_atm_history/rejected_status_selesai";

$route['resend_status'] = "List_laporan_cm/resend_status";
$route['rejected_status'] = "List_laporan_cm/rejected_status";

$route['update_id_atm'] = "List_atm_history/update_id_atm";

$route['cek_id_atm'] = "List_laporan/cek_id_atm";
$route['cek_id_atm_cm'] = "List_laporan_cm/cek_id_atm_cm";


$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";

$route['editOld1'] = "List_atm/editOld1";
$route['editOld2'] = "List_atm/editOld2";

$route['editOld2a'] = "List_laporan/editOld2a";


$route['editOld3'] = "List_laporan/editOld3";
$route['editOld4'] = "List_laporan_cm/editOld4";
$route['editOld4_flm'] = "List_laporan_cm/editOld4_flm";
$route['editOld5'] = "List_laporan_pm/editOld5";
$route['editOld5a'] = "List_laporan_pm/editOld5a";

$route['editOld1/(:num)'] = "List_atm/editOld1/$1";
$route['editOld2/(:num)'] = "List_atm/editOld2/$1";
$route['editOld3/(:num)'] = "List_laporan/editOld3/$1";
$route['editOld4/(:num)'] = "List_laporan_cm/editOld4/$1";
$route['editOld4_flm/(:num)'] = "List_laporan_cm/editOld4_flm/$1";
$route['editOld5/(:num)'] = "List_laporan_pm/editOld5/$1";
$route['editOld5a/(:num)'] = "List_laporan_pm/editOld5a/$1";

$route['editList_atm'] = "List_atm/editList_atm";
$route['editList_atm_2'] = "List_atm/editList_atm_2";


$route['update_id_atm'] = "List_atm_history/update_id_atm";

$route['editList_laporan'] = "List_laporan/editList_laporan";
$route['editList_laporan_cm'] = "List_laporan_cm/editList_laporan_cm";
$route['editList_laporan_cm_flm'] = "List_laporan_cm/editList_laporan_cm_flm";
$route['editList_laporan_pm'] = "List_laporan_pm/editList_laporan_pm";
$route['editList_laporan_pm_2'] = "List_laporan_pm/editList_laporan_pm_2";

$route['deleteUser'] = "user/deleteUser";
$route['deleteList_atm'] = "List_atm/deleteList_atm";
$route['deleteList_laporan'] = "List_laporan/deleteList_laporan";
$route['deleteList_laporan_pm'] = "List_laporan_pm/deleteList_laporan_pm";

$route['download_Report'] = "Report/download_Report";

$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkusernameExists'] = "user/checkusernameExists";

$route['forgotPassword'] = "login/forgotPassword";
$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";

/* End of file routes.php */
/* Location: ./application/config/routes.php */