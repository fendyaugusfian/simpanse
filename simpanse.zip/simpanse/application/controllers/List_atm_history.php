<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : List_atm_history (List_atm_historyController)
 * List_atm_history Class to control all List_atm_history related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class List_atm_history extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_atm_history_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the List_atm_history
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring List_atm_history : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the List_atm_history list
     */
        function List_atm_historyListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $this->load->model('List_atm_history_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $data['id_atmText'] = $id_atmText;
            $this->load->library('pagination');
            
            $count = $this->List_atm_history_model->List_atm_historyListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "List_atm_historyListing/", $count, 5 );
            
            $data['List_atm_historyRecords'] = 
            $this->List_atm_history_model->List_atm_historyListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring List_atm_history : List_atm_history Listing';
            
            $this->loadViews("List_atm_historys", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
    }

    function approved_status_selesai()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai= 'APPROVED BY ADMIN';
            $result = $this->List_atm_history_model->approved_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai);
        
            redirect('List_atm_historyListing');
    }

    function rejected_status_selesai()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai = 'REJECTED BY ADMIN';
            $ket_selesai = $this->input->post('ket_selesai');
            $result = $this->List_atm_history_model->rejected_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai, $ket_selesai);

            redirect('List_atm_historyListing');
    }

        function approved_status_atr()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai= 'APPROVED BY ATR';
            $result = $this->List_atm_history_model->approved_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai);
        
            redirect('List_atm_historyListing');
    }

    function rejected_status_atr()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai = 'REJECTED BY ATR';
            $ket_selesai = $this->input->post('ket_selesai');
            $result = $this->List_atm_history_model->rejected_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai, $ket_selesai);

            redirect('List_atm_historyListing');
    }
}

    
   