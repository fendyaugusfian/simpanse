<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : List_atm_history_details (List_atm_history_detailsController)
 * List_atm_history_details Class to control all List_atm_history_details related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class List_atm_history_details extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_atm_history_details_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the List_atm_history_details
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring List_atm_history_details : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the List_atm_history_details list
     */
        function List_atm_history_detailsListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $this->load->model('List_atm_history_details_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $data['id_atmText'] = $id_atmText;
            $this->load->library('pagination');
            
            $count = $this->List_atm_history_details_model->List_atm_history_detailsListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "List_atm_history_detailsListing/", $count, 5 );
            
            $data['List_atm_history_detailsRecords'] = 
            $this->List_atm_history_details_model->List_atm_history_detailsListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring List_atm_history_details : List_atm_history_details Listing';
            
            $this->loadViews("List_atm_history_detailss", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
    }
}

    
   