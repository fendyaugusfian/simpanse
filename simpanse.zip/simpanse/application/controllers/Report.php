<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Report (ReportController)
 * Report Class to control all Report related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Report extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Report_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Report
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring AI : Dashboard';
    }
    
    /**
     * This function is used to load the Report list
     */
    function ReportListing()
    {
            $this->load->model('Report_model');
            $jenis = $this->input->post('jenis');
            $slm = $this->input->post('slm');
            $tanggalawal = $this->input->post('tanggalawal');    
            $tanggalakhir = $this->input->post('tanggalakhir');
            $wilayah = $this->input->post('wilayah');
            $data['Report'] = $this->Report_model->ReportListing($jenis, $tanggalawal, $tanggalakhir, $slm, $wilayah);
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Report Listing';
            $this->loadViews("Reports", $this->global, $data,  $jenis);

        }
    
    function download_Report()
    {
            $jeniss = $this->input->post('jeniss');
            $file = 'Report/download/'.$jeniss.'.xlsx';
            header('Content-Length: '.filesize($file));
            header('content-disposition: attachment; filename='.$file);
            readfile($file);

        }


}

?>