<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : about (aboutController)
 * about Class to control all about related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class about extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the about
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring about : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the about list
     */
        function aboutListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE  || $this->isSLM() == FALSE )
    {

        
            $this->global['pageTitle'] = 'Monitoring about : about Listing';
            
            $this->loadViews("abouts", $this->global, NULL);
        }
        else
        {
            $this->loadThis();
        }
}


}

    
   