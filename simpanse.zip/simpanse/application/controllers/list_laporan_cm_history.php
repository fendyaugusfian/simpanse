<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_laporan_cm_history (list_laporan_cm_historyController)
 * list_laporan_cm_history Class to control all list_laporan_cm_history related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_laporan_cm_history extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_laporan_cm_history_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_laporan_cm_history
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_laporan_cm_history : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_laporan_cm_history list
     */
        function list_laporan_cm_historyListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
    {
            $this->load->model('List_laporan_cm_history_model');
        
         
            $id_atmText = $this->input->post('id_atmText');

            $data['id_atmText'] = $id_atmText;

            $this->load->library('pagination');
            
            $count = $this->List_laporan_cm_history_model->list_laporan_cm_historyListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "list_laporan_cm_historyListing/", $count, 5 );
            
            $data['list_laporan_cm_historyRecords'] = 
            $this->List_laporan_cm_history_model->list_laporan_cm_historyListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_laporan_cm_history : list_laporan_cm_history Listing';
            
            $this->loadViews("list_laporan_cm_historys", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
}

    function deletelist_laporan_cm_history()
    {
            $id = $this->input->post('id');
            
            $result = $this->List_laporan_cm_history_model->deletelist_laporan_cm_history($id);
        redirect('list_laporan_cm_historyListing');
    }

}

    
   