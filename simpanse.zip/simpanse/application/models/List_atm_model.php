<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class List_atm_model extends CI_Model
{
    /**
     * This function is used to get the List_atm listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function List_atmListingCount($id_atmText ='')
    {
    if($_SESSION['roleText'] == "FLM"){           
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('pengelola', $_SESSION['name']);  
        $query = $this->db->get();
        
        return count($query->result());
    }
    elseif($_SESSION['roleText'] == "SLM"){           
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('nama_pt_slm', $_SESSION['name']);    
        $query = $this->db->get();
        
        return count($query->result());
    }
    elseif($_SESSION['roleText'] == "ATR"){           
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah', $_SESSION['name']);      
        $query = $this->db->get();
        
        return count($query->result());
    }
    elseif($_SESSION['roleText'] == "ADMIN"){           
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $query = $this->db->get();
        
        return count($query->result());
    }
    }
    
    /**
     * This function is used to get the List_atm listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function List_atmListing($id_atmText ='', $page, $segment)
    {
    if($_SESSION['roleText'] == "FLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('pengelola', $_SESSION['name']);  
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    elseif($_SESSION['roleText'] == "SLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('nama_pt_slm', $_SESSION['name']);  
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    elseif($_SESSION['roleText'] == "ATR"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah', $_SESSION['name']);  
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    elseif($_SESSION['roleText'] == "ADMIN"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }    
    }


        function getList_atmInfo($id)
    {
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

        function getList_atm_id_atmInfo($id_atm)
    {
        $this->db->select('BaseTbl.*');
        $this->db->from('List_atm as BaseTbl');
        $this->db->where('id_atm', $id_atm);
        $query = $this->db->get();
        
        return $query->result();
    }

        function addNewList_atm($List_atmInfo)
    {
        $this->db->trans_start();
        $this->db->insert('List_atm', $List_atmInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function editList_atm($List_atmInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('List_atm', $List_atmInfo);
        
        return TRUE;
    }

    function editList_atm_2($List_atmInfo, $id)
    {
        $this->db->trans_start();
        $this->db->insert('List_atm_history', $List_atmInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

      function deleteList_atm($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('List_atm');
        
        return $this->db->affected_rows();
    }

     function clearList_atm()
    {
        $this->db->truncate('List_atm');
    }

    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  