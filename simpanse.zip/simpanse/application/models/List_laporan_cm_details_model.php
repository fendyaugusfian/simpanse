<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class List_laporan_cm_details_model extends CI_Model
{
    /**
     * This function is used to get the List_laporan_cm_details listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function List_laporan_cm_detailsListingCount($id_atmText ='', $nama_pt_slm = '')
    {
    if($_SESSION['roleText'] == "ATR"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('nama_pt_slm', $nama_pt_slm);    
        $this->db->where('status', 'ON PROSES');                 
        $this->db->where('wilayah', $_SESSION['name']);    
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "ADMIN"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('List_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }        
        $this->db->where('nama_pt_slm', $nama_pt_slm);    
        $this->db->where('status', 'ON PROSES');  
        $query = $this->db->get();
        
        return count($query->result());
      }
    }

    /**
     * This function is used to get the List_laporan_cm_details listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function List_laporan_cm_detailsListing($id_atmText ='', $nama_pt_slm = '', $page, $segment)
    {
      if($_SESSION['roleText'] == "ATR"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('List_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        } 
        $this->db->where('nama_pt_slm', $nama_pt_slm);    
        $this->db->where('status', 'ON PROSES');         
        $this->db->where('wilayah', $_SESSION['name']);   
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "ADMIN"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('List_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('nama_pt_slm', $nama_pt_slm);    
        $this->db->where('status', 'ON PROSES');        
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
  }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  