<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class list_laporan_cm_model extends CI_Model
{
    /**
     * This function is used to get the list_laporan_cm listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function list_laporan_cmListingCount($id_atmText ='')
    {
      if($_SESSION['roleText'] == "FLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('nama_petugas_slm', '');
        $this->db->where('pengelola', $_SESSION['name']);           
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "SLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('status', 'ON PROSES');
        $this->db->where('nama_pt_slm', $_SESSION['name']);           
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "ATR"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        } 
        $this->db->where('status', 'ON PROSES');     
        $this->db->where('wilayah', $_SESSION['name']);    
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "ADMIN"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }        
        $this->db->where('status', 'ON PROSES');
        $query = $this->db->get();
        
        return count($query->result());
      }
    }

    /**
     * This function is used to get the list_laporan_cm listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function list_laporan_cmListing($id_atmText ='', $page, $segment)
    {
      if($_SESSION['roleText'] == "FLM"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('nama_petugas_slm', '');
        $this->db->where('pengelola', $_SESSION['name']);      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "SLM"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('status', 'ON PROSES');
        $this->db->where('nama_pt_slm', $_SESSION['name']);      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "ATR"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('status', 'ON PROSES');
        $this->db->where('wilayah', $_SESSION['name']);   
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "ADMIN"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        } 
        $this->db->where('status', 'ON PROSES');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
  }


        function getlist_laporan_cmInfo($id)
    {
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_cm as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

        function cek_id_atm_cm_detail($id_atm)
    {
        $this->db->select('BaseTbl.id, BaseTbl.wilayah, BaseTbl.cabang_pemilik, BaseTbl.lokasi , BaseTbl.jenis_mesin, BaseTbl.tipe_mesin,BaseTbl.serial_mesin, BaseTbl.pengelola, BaseTbl.flm, BaseTbl.pengelola_slm,BaseTbl.nama_pt_slm,BaseTbl.id_atm');
        $this->db->from('list_atm as BaseTbl');
        $this->db->where('id_atm', $id_atm);
        if($_SESSION['roleText'] == "ADMIN"){
        }
        else{
        $this->db->where('pengelola', $_SESSION['name']);
        }
        $query = $this->db->get();
        
        return $query->result();
    }

            
        function addNewlist_laporan_cm($list_laporan_cmInfo)
    {
        $this->db->trans_start();
        $this->db->insert('list_laporan_cm', $list_laporan_cmInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function editlist_laporan_cm($list_laporan_cmInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('list_laporan_cm', $list_laporan_cmInfo);
        
        return TRUE;
    }

    function editlist_laporan_cm_flm($list_laporan_cmInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('list_laporan_cm', $list_laporan_cmInfo);
        
        return TRUE;
    }

      function resend_status($id, $status)
    { 
        $this->db->set('status', $status);      
        $this->db->where('id', $id);
        $this->db->update('list_laporan_cm');
        
        return $this->db->affected_rows();
    }

      function rejected_status($id, $status, $ket_status)
    { 
        $this->db->set('status', $status);  
        $this->db->set('ket_status', $ket_status);     
        $this->db->where('id', $id);
        $this->db->update('list_laporan_cm');
        
        return $this->db->affected_rows();
    }

      function deletelist_laporan_cm($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('list_laporan_cm');
        
        return $this->db->affected_rows();
    }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  