<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class List_laporan_model extends CI_Model
{
    /**
     * This function is used to get the list_laporan listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function list_laporanListingCount($id_atmText ='')
    {   
        if($_SESSION['roleText'] == "ADMIN"){
          $this->db->select('BaseTbl.*');
          $this->db->from('list_laporan as BaseTbl');
          if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
           
        $query = $this->db->get();
        
        return count($query->result());
        }

        elseif($_SESSION['roleText'] == "ATR"){
          $this->db->select('BaseTbl.*');
          $this->db->from('list_laporan as BaseTbl');
          if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
          $bulan_tahun = date('Y-m');
          $this->db->where('substr(tgl_kunjungan,1,7)', $bulan_tahun); 

          $this->db->where('wilayah', $_SESSION['name']);           
          $query = $this->db->get();
        
          return count($query->result());
        }
        else{
          $this->db->select('BaseTbl.*');
          $this->db->from('list_laporan as BaseTbl');
          if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
          $bulan_tahun = date('Y-m');
          $this->db->where('substr(tgl_kunjungan,1,7)', $bulan_tahun); 

          $this->db->where('pihak_yang_melakukan_kunjungan', $_SESSION['name']);           
          $query = $this->db->get();
        
          return count($query->result());
        }
        
    }

    /**
     * This function is used to get the list_laporan listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function list_laporanListing($id_atmText ='', $page, $segment)
    {
        if($_SESSION['roleText'] == "ADMIN"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
        }

      elseif($_SESSION['roleText'] == "ATR"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $bulan_tahun = date('Y-m');
        $this->db->where('substr(tgl_kunjungan,1,7)', $bulan_tahun); 

        $this->db->where('wilayah', $_SESSION['name']);     
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
      else{
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $bulan_tahun = date('Y-m');
        $this->db->where('substr(tgl_kunjungan,1,7)', $bulan_tahun); 

        $this->db->where('pihak_yang_melakukan_kunjungan', $_SESSION['name']);     
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result; 
      }

  }


        function getlist_laporanInfo($id)
    {
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }

        function cek_id_atm_detail($id_atm)
    {
        $this->db->select('BaseTbl.id, BaseTbl.lokasi, BaseTbl.alamat, BaseTbl.kab_kota , BaseTbl.provinsi, BaseTbl.id_atm, BaseTbl.wilayah,BaseTbl.cabang_pemilik,BaseTbl.jenis_mesin,BaseTbl.serial_mesin');
        $this->db->from('list_atm as BaseTbl');
        $this->db->where('id_atm', $id_atm);

        if($_SESSION['roleText'] == "ADMIN"){
        }
        elseif($_SESSION['roleText'] == "ATR"){
        $this->db->where('wilayah', $_SESSION['name']);
        }
        else{
        $this->db->where('pengelola', $_SESSION['name']);
        }
        $query = $this->db->get();
        
        return $query->result();
    }

            function addNewlist_laporan($list_laporanInfo)
    {
        $this->db->trans_start();
        $this->db->insert('list_laporan', $list_laporanInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function editlist_laporan($list_laporanInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('list_laporan', $list_laporanInfo);
        
        return TRUE;
    }


      function deletelist_laporan($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('list_laporan');
        
        return $this->db->affected_rows();
    }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  