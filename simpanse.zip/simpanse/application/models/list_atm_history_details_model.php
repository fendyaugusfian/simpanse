<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class list_atm_history_details_model extends CI_Model
{
    /**
     * This function is used to get the list_atm_history_details listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function list_atm_history_detailsListingCount($id_atmText ='')
    {
    if($_SESSION['roleText'] == "ADMIN"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN');
        $this->db->where_in('status_selesai', $status_selesai);
        $query = $this->db->get();
        
        return count($query->result());
    }
    elseif($_SESSION['roleText'] == "FLM" || $_SESSION['roleText'] == "SLM"  ){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('name_yang_edit', $_SESSION['name']);  
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN', 'REJECTED BY ATR');
        $this->db->where_in('status_selesai', $status_selesai);
        $query = $this->db->get();
        
        return count($query->result());
    }
        elseif($_SESSION['roleText'] == "ATR"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah_asli', $_SESSION['name']);  
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN');
        $this->db->where_in('status_selesai', $status_selesai);
        $query = $this->db->get();
        
        return count($query->result());
    }
    }
    
    /**
     * This function is used to get the list_atm_history_details listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function list_atm_history_detailsListing($id_atmText ='', $page, $segment)
    {
    if($_SESSION['roleText'] == "ADMIN"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN');
        $this->db->where_in('status_selesai', $status_selesai);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    elseif($_SESSION['roleText'] == "FLM" || $_SESSION['roleText'] == "SLM"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('name_yang_edit', $_SESSION['name']);  
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN', 'REJECTED BY ATR');
        $this->db->where_in('status_selesai', $status_selesai);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    } 
    elseif($_SESSION['roleText'] == "ATR"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah_asli', $_SESSION['name']);  
        $status_selesai = array('APPROVED BY ADMIN','REJECTED BY ADMIN');
        $this->db->where_in('status_selesai', $status_selesai);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    } 
    }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  