<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class list_laporan_pm_model extends CI_Model
{
    /**
     * This function is used to get the list_laporan_pm listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function list_laporan_pmListingCount($id_atmText ='')
    {
      if($_SESSION['roleText'] == "FLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');
        $this->db->where('pengelola', $_SESSION['name']);           
        $query = $this->db->get();
        
        return count($query->result());
      }
      if($_SESSION['roleText'] == "SLM"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');
        $this->db->where('nama_pt_slm', $_SESSION['name']);           
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "ATR"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        } 
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');     
        $this->db->where('wilayah', $_SESSION['name']);    
        $query = $this->db->get();
        
        return count($query->result());
      }
      elseif($_SESSION['roleText'] == "ADMIN"){   
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
          $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
          $this->db->where($likeCriteria);
        }        
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');   
        $query = $this->db->get();
        
        return count($query->result());
      }
    }

    /**
     * This function is used to get the list_laporan_pm listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function list_laporan_pmListing($id_atmText ='', $page, $segment)
    {
      if($_SESSION['roleText'] == "FLM"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');   
        $this->db->where('pengelola', $_SESSION['name']);      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
      if($_SESSION['roleText'] == "SLM"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');   
        $this->db->where('nama_pt_slm', $_SESSION['name']);      
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "ATR"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');   
        $this->db->where('wilayah', $_SESSION['name']);   
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
       elseif($_SESSION['roleText'] == "ADMIN"){          
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        } 
        $this->db->where('jumlah_rencana !=', 'jumlah_realisasi');   
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
      }
  }


        function getlist_laporan_pmInfo($id)
    {
        $this->db->select('BaseTbl.*');
        $this->db->from('list_laporan_pm as BaseTbl');
        $this->db->where('id', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    function editlist_laporan_pm($list_laporan_pmInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('list_laporan_pm', $list_laporan_pmInfo);
        
        
        return TRUE;
    }

        function editlist_laporan_pm_2($list_laporan_pmInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('list_laporan_pm', $list_laporan_pmInfo);
        
        return TRUE;
    }
    
      function deletelist_laporan_pm($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('list_laporan_pm');
        
        return $this->db->affected_rows();
    }

    function clearlist_laporan_pm()
    {
        $this->db->truncate('list_laporan_pm');
    }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  