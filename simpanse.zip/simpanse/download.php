<?php 

$file = 'report/download/'.$_POST['jeniss'].'.xlsx';
header('Content-Length: '.filesize($file));
header('content-disposition: attachment; filename='.$file);
readfile($file);


 ?>