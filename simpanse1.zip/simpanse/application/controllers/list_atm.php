<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_atm (list_atmController)
 * list_atm Class to control all list_atm related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_atm extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_atm_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_atm
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_atm : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_atm list
     */
        function list_atmListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $this->load->model('List_atm_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $data['id_atmText'] = $id_atmText;
            $this->load->library('pagination');
            
            $count = $this->List_atm_model->list_atmListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "list_atmListing/", $count, 5 );
            
            $data['list_atmRecords'] = 
            $this->List_atm_model->list_atmListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_atm : list_atm Listing';
            
            $this->loadViews("list_atms", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
}
      function addnew1()
    {
    if($this->isAdmin() == FALSE)
    {
            $this->load->model('List_atm_model');
            
            $this->global['pageTitle'] = 'SIMPANSE: Add New List ATM';

            $this->loadViews("addNew1", $this->global, NULL);
        }
    }

    function addNewlist_atm()
    {
            $id_atm= $this->input->post('id_atm');
            $lokasi= $this->input->post('lokasi');
            $alamat= $this->input->post('alamat');
            $kab_kota= $this->input->post('kab_kota');
            $provinsi= $this->input->post('provinsi');
            $pengelola= $this->input->post('pengelola');
            $flm= $this->input->post('flm');
            $sis= $this->input->post('sis');
            $kelolaan= $this->input->post('kelolaan');
            $wilayah= $this->input->post('wilayah');
            $cabang_pemilik= $this->input->post('cabang_pemilik');
            $tipe_mesin= $this->input->post('tipe_mesin');
            $jenis_atm= $this->input->post('jenis_atm');
            $merk_mesin= $this->input->post('merk_mesin');
            $jenis_mesin= $this->input->post('jenis_mesin');
            $komunikasi= $this->input->post('komunikasi');
            $denom= $this->input->post('denom');
            $tahun_mesin= $this->input->post('tahun_mesin');
            $tahun_deploy= $this->input->post('tahun_deploy');
            $rbb= $this->input->post('rbb');
            $serial_mesin= $this->input->post('serial_mesin');
            $os_version= $this->input->post('os_version');
            $tanggal_aktivasi= $this->input->post('tanggal_aktivasi');
            $in_off_branch= $this->input->post('in_off_branch');
            $gallery_single= $this->input->post('gallery_single');
            $area= $this->input->post('area');
            $booth= $this->input->post('booth');
            $keterangan= $this->input->post('keterangan');
            $card_reader= $this->input->post('card_reader');
            $umur_mesin= $this->input->post('umur_mesin');
            $pengelola_slm= $this->input->post('pengelola_slm');
            $kriteria_mesin= $this->input->post('kriteria_mesin');
            $cctv= $this->input->post('cctv');
            $kode_replenishment= $this->input->post('kode_replenishment');
            $hidden_cctv= $this->input->post('hidden_cctv');
            $askim= $this->input->post('askim');
            $anti_deep_insert_skimming_2018= $this->input->post('anti_deep_insert_skimming_2018');
            $anti_skimming_eksternal= $this->input->post('anti_skimming_eksternal');
            $whitelisting= $this->input->post('whitelisting');
            $merah_putih= $this->input->post('merah_putih');
            $mac= $this->input->post('mac');
            $tapcash= $this->input->post('tapcash');
            $emv= $this->input->post('emv');
            $nama_pt_slm= $this->input->post('nama_pt_slm');


        $list_atmInfo = array(
            'id_atm'=>$id_atm,
            'lokasi'=>$lokasi,
            'alamat'=>$alamat,
            'kab_kota'=>$kab_kota,
            'provinsi'=>$provinsi,
            'pengelola'=>$pengelola,
            'flm'=>$flm,
            'sis'=>$sis,
            'kelolaan'=>$kelolaan,
            'wilayah'=>$wilayah,
            'cabang_pemilik'=>$cabang_pemilik,
            'tipe_mesin'=>$tipe_mesin,
            'jenis_atm'=>$jenis_atm,
            'merk_mesin'=>$merk_mesin,
            'jenis_mesin'=>$jenis_mesin,
            'komunikasi'=>$komunikasi,
            'denom'=>$denom,
            'tahun_mesin'=>$tahun_mesin,
            'tahun_deploy'=>$tahun_deploy,
            'rbb'=>$rbb,
            'serial_mesin'=>$serial_mesin,
            'os_version'=>$os_version,
            'tanggal_aktivasi'=>$tanggal_aktivasi,
            'in_off_branch'=>$in_off_branch,
            'gallery_single'=>$gallery_single,
            'area'=>$area,
            'booth'=>$booth,
            'keterangan'=>$keterangan,
            'card_reader'=>$card_reader,
            'umur_mesin'=>$umur_mesin,
            'pengelola_slm'=>$pengelola_slm,
            'kriteria_mesin'=>$kriteria_mesin,
            'cctv'=>$cctv,
            'kode_replenishment'=>$kode_replenishment,
            'hidden_cctv'=>$hidden_cctv,
            'askim'=>$askim,
            'anti_deep_insert_skimming_2018'=>$anti_deep_insert_skimming_2018,
            'anti_skimming_eksternal'=>$anti_skimming_eksternal,
            'whitelisting'=>$whitelisting,
            'merah_putih'=>$merah_putih,
            'mac'=>$mac,
            'tapcash'=>$tapcash,
            'emv'=>$emv,
            'nama_pt_slm'=>$nama_pt_slm,

                );
                
        $this->load->model('List_atm_model');
        $result = $this->List_atm_model->addNewlist_atm($list_atmInfo);
                
                
        redirect('list_atmListing');
            
    }

    function editOld1($id = NULL)
    {
        if($this->isAdmin() == FALSE)
        {
            if($id == null)
            {
                redirect('list_atmListing');
            }
    
            $data['list_atmInfo'] = $this->List_atm_model->getlist_atmInfo($id);
            
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit List_atm';
            
            $this->loadViews("editOld1", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the visa_retail information
     */
    function editlist_atm()
    {
        if($this->isAdmin() == FALSE)
        {
            $id = $this->input->post('id');
            $id_atm= $this->input->post('id_atm');
            $lokasi= $this->input->post('lokasi');
            $alamat= $this->input->post('alamat');
            $kab_kota= $this->input->post('kab_kota');
            $provinsi= $this->input->post('provinsi');
            $pengelola= $this->input->post('pengelola');
            $flm= $this->input->post('flm');
            $sis= $this->input->post('sis');
            $kelolaan= $this->input->post('kelolaan');
            $wilayah= $this->input->post('wilayah');
            $cabang_pemilik= $this->input->post('cabang_pemilik');
            $tipe_mesin= $this->input->post('tipe_mesin');
            $jenis_atm= $this->input->post('jenis_atm');
            $merk_mesin= $this->input->post('merk_mesin');
            $jenis_mesin= $this->input->post('jenis_mesin');
            $komunikasi= $this->input->post('komunikasi');
            $denom= $this->input->post('denom');
            $tahun_mesin= $this->input->post('tahun_mesin');
            $tahun_deploy= $this->input->post('tahun_deploy');
            $rbb= $this->input->post('rbb');
            $serial_mesin= $this->input->post('serial_mesin');
            $os_version= $this->input->post('os_version');
            $tanggal_aktivasi= $this->input->post('tanggal_aktivasi');
            $in_off_branch= $this->input->post('in_off_branch');
            $gallery_single= $this->input->post('gallery_single');
            $area= $this->input->post('area');
            $booth= $this->input->post('booth');
            $keterangan= $this->input->post('keterangan');
            $card_reader= $this->input->post('card_reader');
            $umur_mesin= $this->input->post('umur_mesin');
            $pengelola_slm= $this->input->post('pengelola_slm');
            $kriteria_mesin= $this->input->post('kriteria_mesin');
            $cctv= $this->input->post('cctv');
            $kode_replenishment= $this->input->post('kode_replenishment');
            $hidden_cctv= $this->input->post('hidden_cctv');
            $askim= $this->input->post('askim');
            $anti_deep_insert_skimming_2018= $this->input->post('anti_deep_insert_skimming_2018');
            $anti_skimming_eksternal= $this->input->post('anti_skimming_eksternal');
            $whitelisting= $this->input->post('whitelisting');
            $merah_putih= $this->input->post('merah_putih');
            $mac= $this->input->post('mac');
            $tapcash= $this->input->post('tapcash');
            $emv= $this->input->post('emv');
            $nama_pt_slm= $this->input->post('nama_pt_slm');


        $list_atmInfo = array(
            'id'=>$id,
            'id_atm'=>$id_atm,
            'lokasi'=>$lokasi,
            'alamat'=>$alamat,
            'kab_kota'=>$kab_kota,
            'provinsi'=>$provinsi,
            'pengelola'=>$pengelola,
            'flm'=>$flm,
            'sis'=>$sis,
            'kelolaan'=>$kelolaan,
            'wilayah'=>$wilayah,
            'cabang_pemilik'=>$cabang_pemilik,
            'tipe_mesin'=>$tipe_mesin,
            'jenis_atm'=>$jenis_atm,
            'merk_mesin'=>$merk_mesin,
            'jenis_mesin'=>$jenis_mesin,
            'komunikasi'=>$komunikasi,
            'denom'=>$denom,
            'tahun_mesin'=>$tahun_mesin,
            'tahun_deploy'=>$tahun_deploy,
            'rbb'=>$rbb,
            'serial_mesin'=>$serial_mesin,
            'os_version'=>$os_version,
            'tanggal_aktivasi'=>$tanggal_aktivasi,
            'in_off_branch'=>$in_off_branch,
            'gallery_single'=>$gallery_single,
            'area'=>$area,
            'booth'=>$booth,
            'keterangan'=>$keterangan,
            'card_reader'=>$card_reader,
            'umur_mesin'=>$umur_mesin,
            'pengelola_slm'=>$pengelola_slm,
            'kriteria_mesin'=>$kriteria_mesin,
            'cctv'=>$cctv,
            'kode_replenishment'=>$kode_replenishment,
            'hidden_cctv'=>$hidden_cctv,
            'askim'=>$askim,
            'anti_deep_insert_skimming_2018'=>$anti_deep_insert_skimming_2018,
            'anti_skimming_eksternal'=>$anti_skimming_eksternal,
            'whitelisting'=>$whitelisting,
            'merah_putih'=>$merah_putih,
            'mac'=>$mac,
            'tapcash'=>$tapcash,
            'emv'=>$emv,
            'nama_pt_slm'=>$nama_pt_slm,
                );
                
            $result = $this->List_atm_model->editlist_atm($list_atmInfo, $id);
                
            redirect('list_atmListing');
            
        }
    }

    function editOld2($id = NULL)
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            if($id == null)
            {
                redirect('list_atmListing');
            }
    
            $data['list_atmInfo'] = $this->List_atm_model->getlist_atmInfo($id);
            
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit List_atm';
            
            $this->loadViews("editOld2", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the visa_retail information
     */
    function editlist_atm_2()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $tgl_edit = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_edit= date('H:i:s');
            $name_yang_edit= $_SESSION['name'];

            if($this->isFLM() == FALSE || $this->isSLM() == FALSE){
                $status_selesai = 'ON PROSES';
            }

            if($this->isATR() == FALSE){
                $tgl_selesai = date('Y-m-d');
                date_default_timezone_set("Asia/Bangkok");
                $jam_selesai = date('H:i:s');
                $status_selesai = 'APPROVED BY ATR';
            }           

            $id = $this->input->post('id');
            $id_atm= $this->input->post('id_atm');
            $wilayah_asli= $this->input->post('wilayah_asli');
            $lokasi= $this->input->post('lokasi');
            $alamat= $this->input->post('alamat');
            $kab_kota= $this->input->post('kab_kota');
            $provinsi= $this->input->post('provinsi');
            $pengelola= $this->input->post('pengelola');
            $flm= $this->input->post('flm');
            $sis= $this->input->post('sis');
            $kelolaan= $this->input->post('kelolaan');
            $wilayah= $this->input->post('wilayah');
            $cabang_pemilik= $this->input->post('cabang_pemilik');
            $tipe_mesin= $this->input->post('tipe_mesin');
            $jenis_atm= $this->input->post('jenis_atm');
            $merk_mesin= $this->input->post('merk_mesin');
            $jenis_mesin= $this->input->post('jenis_mesin');
            $komunikasi= $this->input->post('komunikasi');
            $denom= $this->input->post('denom');
            $tahun_mesin= $this->input->post('tahun_mesin');
            $tahun_deploy= $this->input->post('tahun_deploy');
            $rbb= $this->input->post('rbb');
            $serial_mesin= $this->input->post('serial_mesin');
            $os_version= $this->input->post('os_version');
            $tanggal_aktivasi= $this->input->post('tanggal_aktivasi');
            $in_off_branch= $this->input->post('in_off_branch');
            $gallery_single= $this->input->post('gallery_single');
            $area= $this->input->post('area');
            $booth= $this->input->post('booth');
            $keterangan= $this->input->post('keterangan');
            $card_reader= $this->input->post('card_reader');
            $umur_mesin= $this->input->post('umur_mesin');
            $pengelola_slm= $this->input->post('pengelola_slm');
            $kriteria_mesin= $this->input->post('kriteria_mesin');
            $cctv= $this->input->post('cctv');
            $kode_replenishment= $this->input->post('kode_replenishment');
            $hidden_cctv= $this->input->post('hidden_cctv');
            $askim= $this->input->post('askim');
            $anti_deep_insert_skimming_2018= $this->input->post('anti_deep_insert_skimming_2018');
            $anti_skimming_eksternal= $this->input->post('anti_skimming_eksternal');
            $whitelisting= $this->input->post('whitelisting');
            $merah_putih= $this->input->post('merah_putih');
            $mac= $this->input->post('mac');
            $tapcash= $this->input->post('tapcash');
            $emv= $this->input->post('emv');
            $nama_pt_slm= $this->input->post('nama_pt_slm');


        $list_atmInfo = array(
            'tgl_edit'=>$tgl_edit,
            'jam_edit'=>$jam_edit,
            'name_yang_edit'=>$name_yang_edit,
            'tgl_selesai'=>$tgl_selesai,
            'jam_selesai'=>$jam_selesai,
            'status_selesai'=>$status_selesai,
            'id'=>$id,
            'id_atm'=>$id_atm,
            'wilayah_asli'=>$wilayah_asli,            
            'lokasi'=>$lokasi,
            'alamat'=>$alamat,
            'kab_kota'=>$kab_kota,
            'provinsi'=>$provinsi,
            'pengelola'=>$pengelola,
            'flm'=>$flm,
            'sis'=>$sis,
            'kelolaan'=>$kelolaan,
            'wilayah'=>$wilayah,
            'cabang_pemilik'=>$cabang_pemilik,
            'tipe_mesin'=>$tipe_mesin,
            'jenis_atm'=>$jenis_atm,
            'merk_mesin'=>$merk_mesin,
            'jenis_mesin'=>$jenis_mesin,
            'komunikasi'=>$komunikasi,
            'denom'=>$denom,
            'tahun_mesin'=>$tahun_mesin,
            'tahun_deploy'=>$tahun_deploy,
            'rbb'=>$rbb,
            'serial_mesin'=>$serial_mesin,
            'os_version'=>$os_version,
            'tanggal_aktivasi'=>$tanggal_aktivasi,
            'in_off_branch'=>$in_off_branch,
            'gallery_single'=>$gallery_single,
            'area'=>$area,
            'booth'=>$booth,
            'keterangan'=>$keterangan,
            'card_reader'=>$card_reader,
            'umur_mesin'=>$umur_mesin,
            'pengelola_slm'=>$pengelola_slm,
            'kriteria_mesin'=>$kriteria_mesin,
            'cctv'=>$cctv,
            'kode_replenishment'=>$kode_replenishment,
            'hidden_cctv'=>$hidden_cctv,
            'askim'=>$askim,
            'anti_deep_insert_skimming_2018'=>$anti_deep_insert_skimming_2018,
            'anti_skimming_eksternal'=>$anti_skimming_eksternal,
            'whitelisting'=>$whitelisting,
            'merah_putih'=>$merah_putih,
            'mac'=>$mac,
            'tapcash'=>$tapcash,
            'emv'=>$emv,
            'nama_pt_slm'=>$nama_pt_slm,
                );
                
            $result = $this->List_atm_model->editlist_atm_2($list_atmInfo, $id);
                
            redirect('dashboard');
            
        }
    }

    function deletelist_atm()
    {
            $id = $this->input->post('id');
            
            $result = $this->List_atm_model->deletelist_atm($id);
        redirect('list_atmListing');
    }

    function clearlist_atm()
    {
            $result = $this->List_atm_model->clearlist_atm();
            redirect('list_atmListing');
    }

    function formlist_atm()
    {
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit List_atm';
            
            $this->loadViews("formlist_atm", $this->global, NULL);
    }

    public function upload()
    {
        // Load plugin PHPExcel nya
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';

        $config['upload_path'] = realpath('excel');
        $config['allowed_types'] = 'xlsx|xls|csv';
        $config['max_size'] = '1000000';
        $config['encrypt_name'] = true;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()) {

            //upload gagal
            $this->session->set_flashdata('notif', '<div class="alert alert-danger"><b>PROSES IMPORT GAGAL!</b> '.$this->upload->display_errors().'</div>');
            //redirect halaman
            redirect('import/');

        } else {

            $data_upload = $this->upload->data();

            $excelreader     = new PHPExcel_Reader_Excel2007();
            $loadexcel         = $excelreader->load('excel/'.$data_upload['file_name']); // Load file yang telah diupload ke folder excel
            $sheet             = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

            $data = array();

            $numrow = 1;
            foreach($sheet as $row){
                            if($numrow > 1){
                                array_push($data, array(
                                'id_atm' => $row['B'],
                                'lokasi' => $row['C'],
                                'alamat' => $row['D'],
                                'kab_kota' => $row['E'],
                                'provinsi' => $row['F'],
                                'pengelola' => $row['G'],
                                'flm' => $row['H'],
                                'sis' => $row['I'],
                                'kelolaan' => $row['J'],
                                'wilayah' => $row['K'],
                                'cabang_pemilik' => $row['L'],
                                'tipe_mesin' => $row['M'],
                                'jenis_atm' => $row['N'],
                                'merk_mesin' => $row['O'],
                                'jenis_mesin' => $row['P'],
                                'komunikasi' => $row['Q'],
                                'denom' => $row['R'],
                                'tahun_mesin' => $row['S'],
                                'tahun_deploy' => $row['T'],
                                'rbb' => $row['U'],
                                'serial_mesin' => $row['V'],
                                'os_version' => $row['W'],
                                'tanggal_aktivasi' => $row['X'],
                                'in_off_branch' => $row['Y'],
                                'gallery_single' => $row['Z'],
                                'area' => $row['AA'],
                                'booth' => $row['AB'],
                                'keterangan' => $row['AC'],
                                'card_reader' => $row['AD'],
                                'umur_mesin' => $row['AE'],
                                'pengelola_slm' => $row['AF'],
                                'kriteria_mesin' => $row['AG'],
                                'cctv' => $row['AH'],
                                'kode_replenishment' => $row['AI'],
                                'hidden_cctv' => $row['AJ'],
                                'askim' => $row['AK'],
                                'anti_deep_insert_skimming_2018' => $row['AL'],
                                'anti_skimming_eksternal' => $row['AM'],
                                'whitelisting' => $row['AN'],
                                'merah_putih' => $row['AO'],
                                'mac' => $row['AP'],
                                'tapcash' => $row['AQ'],
                                'emv' => $row['AR'],
                                'nama_pt_slm' => $row['AS']
                                ));
                    }
                $numrow++;
            }
            $this->db->insert_batch('list_atm', $data);
            //delete file from server
            unlink(realpath('excel/'.$data_upload['file_name']));

            //upload success
            $this->session->set_flashdata('notif', '<div class="alert alert-success"><b>PROSES IMPORT BERHASIL!</b> Data berhasil diimport!</div>');
            //redirect halaman
            redirect('dashboard');

        }
    }
}

    
   