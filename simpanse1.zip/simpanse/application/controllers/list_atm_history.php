<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_atm_history (list_atm_historyController)
 * list_atm_history Class to control all list_atm_history related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_atm_history extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_atm_history_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_atm_history
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_atm_history : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_atm_history list
     */
        function list_atm_historyListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $this->load->model('List_atm_history_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $data['id_atmText'] = $id_atmText;
            $this->load->library('pagination');
            
            $count = $this->List_atm_history_model->list_atm_historyListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "list_atm_historyListing/", $count, 5 );
            
            $data['list_atm_historyRecords'] = 
            $this->List_atm_history_model->list_atm_historyListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_atm_history : list_atm_history Listing';
            
            $this->loadViews("list_atm_historys", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
    }

    function approved_status_selesai()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai= 'APPROVED BY ADMIN';
            $result = $this->List_atm_history_model->approved_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai);
        
            redirect('list_atm_historyListing');
    }

    function rejected_status_selesai()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai = 'REJECTED BY ADMIN';
            $ket_selesai = $this->input->post('ket_selesai');
            $result = $this->List_atm_history_model->rejected_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai, $ket_selesai);

            redirect('list_atm_historyListing');
    }

        function approved_status_atr()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai= 'APPROVED BY ATR';
            $result = $this->List_atm_history_model->approved_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai);
        
            redirect('list_atm_historyListing');
    }

    function rejected_status_atr()
    {
            $id_edit = $this->input->post('id_edit');
            $tgl_selesai = date('Y-m-d');
            date_default_timezone_set("Asia/Bangkok");
            $jam_selesai = date('H:i:s');
            $status_selesai = 'REJECTED BY ATR';
            $ket_selesai = $this->input->post('ket_selesai');
            $result = $this->List_atm_history_model->rejected_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai, $ket_selesai);

            redirect('list_atm_historyListing');
    }
}

    
   