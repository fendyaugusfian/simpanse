<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_laporan_cm_details (list_laporan_cm_detailsController)
 * list_laporan_cm_details Class to control all list_laporan_cm_details related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_laporan_cm_details extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_laporan_cm_details_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_laporan_cm_details
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_laporan_cm_details : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_laporan_cm_details list
     */
        function list_laporan_cm_detailsListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE )
    {
            $this->load->model('List_laporan_cm_details_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $nama_pt_slm = $this->input->post('nama_pt_slm');
            $data['id_atmText'] = $id_atmText;
            $data['nama_pt_slm'] = $nama_pt_slm;
            $this->load->library('pagination');
            
            $count = $this->List_laporan_cm_details_model->list_laporan_cm_detailsListingCount($id_atmText, $nama_pt_slm);
            
            $returns = $this->paginationCompress ( "list_laporan_cm_detailsListing/", $count, 5 );
            
            $data['list_laporan_cm_detailsRecords'] = 
            $this->List_laporan_cm_details_model->list_laporan_cm_detailsListing($id_atmText, $nama_pt_slm, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_laporan_cm_details : list_laporan_cm_details Listing';
            
            $this->loadViews("list_laporan_cm_detailss", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
}


}

    
   