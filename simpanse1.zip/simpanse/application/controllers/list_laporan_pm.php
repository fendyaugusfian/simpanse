<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_laporan_pm (list_laporan_pmController)
 * list_laporan_pm Class to control all list_laporan_pm related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_laporan_pm extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('List_laporan_pm_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_laporan_pm
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_laporan_pm : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_laporan_pm list
     */
        function list_laporan_pmListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE | $this->isSLM() == FALSE)
    {
            $this->load->model('List_laporan_pm_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            
            $data['id_atmText'] = $id_atmText;

            $this->load->library('pagination');
            
            $count = $this->List_laporan_pm_model->list_laporan_pmListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "list_laporan_pmListing/", $count, 5 );
            
            $data['list_laporan_pmRecords'] = 
            $this->List_laporan_pm_model->list_laporan_pmListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_laporan_pm : list_laporan_pm Listing';
            
            $this->loadViews("list_laporan_pms", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
}

 function editOld5($id = NULL)
    {
        if($this->isAdmin() == FALSE)
        {
            if($id == null)
            {
                redirect('list_laporan_pmListing');
            }
    
            $data['list_laporan_pmInfo'] = $this->List_laporan_pm_model->getlist_laporan_pmInfo($id);
            
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit list_laporan_pm';
            
            $this->loadViews("editOld5", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the visa_retail information
     */
    function editlist_laporan_pm()
    {
        if($this->isAdmin() == FALSE)
        {
            $id = $this->input->post('id');
            $id_atm = $this->input->post('id_atm');
            $wilayah = $this->input->post('wilayah');
            $lokasi = $this->input->post('lokasi');
            $cabang_pemilik = $this->input->post('cabang_pemilik');
            $alamat = $this->input->post('alamat');
            $pengelola = $this->input->post('pengelola');
            $nama_pt_slm = $this->input->post('nama_pt_slm');
            $serial_mesin = $this->input->post('serial_mesin');
            $merk_atm = $this->input->post('merk_atm');
            $tipe_atm = $this->input->post('tipe_atm');
            $tahun = $this->input->post('tahun');
            $tanggal_aktivasi = $this->input->post('tanggal_aktivasi');
            $sla_part = $this->input->post('sla_part');
            $merk_cctv = $this->input->post('merk_cctv');
            $serial_number_cctv  = $this->input->post('serial_number_cctv');
            $kondisi_kamera_cctv_dvr  = $this->input->post('kondisi_kamera_cctv_dvr');
            $merk_ups  = $this->input->post('merk_ups');
            $serial_number_ups  = $this->input->post('serial_number_ups');
            $kondisi_ups  = $this->input->post('kondisi_ups');
            $tegangan  = $this->input->post('tegangan');
            $ground  = $this->input->post('ground');
            $suhu_ruang  = $this->input->post('suhu_ruang');
            $status_merah_putih  = $this->input->post('status_merah_putih');
            $emv  = $this->input->post('emv');
            $mackey  = $this->input->post('mackey');
            $whitelisting  = $this->input->post('whitelisting');
            $agent_based  = $this->input->post('agent_based');
            $tapcash  = $this->input->post('tapcash');
            $enable_firewall  = $this->input->post('enable_firewall');
            $disable_smb  = $this->input->post('disable_smb');
            $ip_address  = $this->input->post('ip_address');
            $jumlah_rencana = $this->input->post('jumlah_rencana');
            $jumlah_realisasi = $this->input->post('jumlah_realisasi');
            $rencana_pm_1 = $this->input->post('rencana_pm_1');
            $rencana_pm_2 = $this->input->post('rencana_pm_2');
            $rencana_pm_3 = $this->input->post('rencana_pm_3');
            $rencana_pm_4 = $this->input->post('rencana_pm_4');
            $tgl_realisasi_pm_1 = $this->input->post('tgl_realisasi_pm_1');
            $tgl_realisasi_pm_2 = $this->input->post('tgl_realisasi_pm_2');
            $tgl_realisasi_pm_3 = $this->input->post('tgl_realisasi_pm_3');
            $tgl_realisasi_pm_4 = $this->input->post('tgl_realisasi_pm_4');



        $list_laporan_pmInfo = array(
            'id'=>$id,
            'id_atm'=>$id_atm,
            'wilayah'=>$wilayah,
            'lokasi'=>$lokasi,
            'cabang_pemilik'=>$cabang_pemilik,
            'alamat'=>$alamat,
            'pengelola'=>$pengelola,
            'nama_pt_slm'=>$nama_pt_slm,           
            'serial_mesin'=>$serial_mesin,
            'merk_atm'=>$merk_atm,
            'tipe_atm'=>$tipe_atm,
            'tahun'=>$tahun,
            'tanggal_aktivasi'=>$tanggal_aktivasi,
            'sla_part'=>$sla_part,
            'merk_cctv'=>$merk_cctv,
            'serial_number_cctv'=>$serial_number_cctv,
            'kondisi_kamera_cctv_dvr'=>$kondisi_kamera_cctv_dvr,
            'merk_ups'=>$merk_ups,
            'serial_number_ups'=>$serial_number_ups,
            'kondisi_ups'=>$kondisi_ups,
            'tegangan'=>$tegangan,
            'ground'=>$ground,
            'suhu_ruang'=>$suhu_ruang,
            'status_merah_putih'=>$status_merah_putih ,
            'emv'=>$emv,
            'mackey'=>$mackey,
            'whitelisting'=>$whitelisting,
            'agent_based'=>$agent_based,
            'tapcash'=>$tapcash,
            'enable_firewall'=>$enable_firewall,
            'disable_smb'=>$disable_smb,
            'ip_address'=>$ip_address,
            'jumlah_rencana'=>$jumlah_rencana,
            'jumlah_realisasi'=>$jumlah_realisasi,
            'rencana_pm_1'=>$rencana_pm_1,
            'rencana_pm_2'=>$rencana_pm_2,
            'rencana_pm_3'=>$rencana_pm_3,
            'rencana_pm_4'=>$rencana_pm_4,
            'tgl_realisasi_pm_1'=>$tgl_realisasi_pm_1,
            'tgl_realisasi_pm_2'=>$tgl_realisasi_pm_2,
            'tgl_realisasi_pm_3'=>$tgl_realisasi_pm_3,
            'tgl_realisasi_pm_4'=>$tgl_realisasi_pm_4,
                );
                
            $result = $this->List_laporan_pm_model->editlist_laporan_pm($list_laporan_pmInfo, $id);
                
            redirect('list_laporan_pmListing');
            
        }
    }

function editOld5a($id = NULL)
    {
        if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE)
        {
            if($id == null)
            {
                redirect('list_laporan_pmListing');
            }
    
            $data['list_laporan_pmInfo'] = $this->List_laporan_pm_model->getlist_laporan_pmInfo($id);
            
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit list_laporan_pm';
            
            $this->loadViews("editOld5a", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the visa_retail information
     */
    function editlist_laporan_pm_2()
    {
        if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE)
        {
            $id = $this->input->post('id');
            $id_atm = $this->input->post('id_atm');
            $wilayah = $this->input->post('wilayah');
            $lokasi = $this->input->post('lokasi');
            $cabang_pemilik = $this->input->post('cabang_pemilik');
            $alamat = $this->input->post('alamat');
            $pengelola = $this->input->post('pengelola');
            $nama_pt_slm = $this->input->post('nama_pt_slm');
            $serial_mesin = $this->input->post('serial_mesin');
            $merk_atm = $this->input->post('merk_atm');
            $tipe_atm = $this->input->post('tipe_atm');
            $tahun = $this->input->post('tahun');
            $tanggal_aktivasi = $this->input->post('tanggal_aktivasi');
            $sla_part = $this->input->post('sla_part');
            $merk_cctv = $this->input->post('merk_cctv');
            $serial_number_cctv  = $this->input->post('serial_number_cctv');
            $kondisi_kamera_cctv_dvr  = $this->input->post('kondisi_kamera_cctv_dvr');
            $merk_ups  = $this->input->post('merk_ups');
            $serial_number_ups  = $this->input->post('serial_number_ups');
            $kondisi_ups  = $this->input->post('kondisi_ups');
            $tegangan  = $this->input->post('tegangan');
            $ground  = $this->input->post('ground');
            $suhu_ruang  = $this->input->post('suhu_ruang');
            $status_merah_putih  = $this->input->post('status_merah_putih');
            $emv  = $this->input->post('emv');
            $mackey  = $this->input->post('mackey');
            $whitelisting  = $this->input->post('whitelisting');
            $agent_based  = $this->input->post('agent_based');
            $tapcash  = $this->input->post('tapcash');
            $enable_firewall  = $this->input->post('enable_firewall');
            $disable_smb  = $this->input->post('disable_smb');
            $ip_address  = $this->input->post('ip_address');

            $rencana_pm_1 = $this->input->post('rencana_pm_1');
            $rencana_pm_2 = $this->input->post('rencana_pm_2');
            $rencana_pm_3 = $this->input->post('rencana_pm_3');
            $rencana_pm_4 = $this->input->post('rencana_pm_4');
            $tgl_realisasi_pm_1 = $this->input->post('tgl_realisasi_pm_1');
            $tgl_realisasi_pm_2 = $this->input->post('tgl_realisasi_pm_2');
            $tgl_realisasi_pm_3 = $this->input->post('tgl_realisasi_pm_3');
            $tgl_realisasi_pm_4 = $this->input->post('tgl_realisasi_pm_4');

            if($tgl_realisasi_pm_1 != ''){
                $jumlah1 = "1";
            }
            else { $jumlah1 = "0";}
            if($tgl_realisasi_pm_2 != ''){
                $jumlah2 = "1";
            }
            else { $jumlah2 = "0";}
            if($tgl_realisasi_pm_3 != ''){
                $jumlah3 = "1";
            }
            else { $jumlah3 = "0";}
            if($tgl_realisasi_pm_4 != ''){
                $jumlah4 = "1";
            }
            else { $jumlah4 = "0";}

            $jumlah_realisasi = $jumlah1 + $jumlah2 + $jumlah3 + $jumlah4;

        $list_laporan_pmInfo = array(
            'id'=>$id,
            'id_atm'=>$id_atm,
            'wilayah'=>$wilayah,
            'lokasi'=>$lokasi,
            'cabang_pemilik'=>$cabang_pemilik,
            'alamat'=>$alamat,
            'pengelola'=>$pengelola,
            'nama_pt_slm'=>$nama_pt_slm,           
            'serial_mesin'=>$serial_mesin,
            'merk_atm'=>$merk_atm,
            'tipe_atm'=>$tipe_atm,
            'tahun'=>$tahun,
            'tanggal_aktivasi'=>$tanggal_aktivasi,
            'sla_part'=>$sla_part,
            'merk_cctv'=>$merk_cctv,
            'serial_number_cctv'=>$serial_number_cctv,
            'kondisi_kamera_cctv_dvr'=>$kondisi_kamera_cctv_dvr,
            'merk_ups'=>$merk_ups,
            'serial_number_ups'=>$serial_number_ups,
            'kondisi_ups'=>$kondisi_ups,
            'tegangan'=>$tegangan,
            'ground'=>$ground,
            'suhu_ruang'=>$suhu_ruang,
            'status_merah_putih'=>$status_merah_putih ,
            'emv'=>$emv,
            'mackey'=>$mackey,
            'whitelisting'=>$whitelisting,
            'agent_based'=>$agent_based,
            'tapcash'=>$tapcash,
            'enable_firewall'=>$enable_firewall,
            'disable_smb'=>$disable_smb,
            'ip_address'=>$ip_address,
            'jumlah_rencana'=>$jumlah_rencana,
            'jumlah_realisasi'=>$jumlah_realisasi,
            'rencana_pm_1'=>$rencana_pm_1,
            'rencana_pm_2'=>$rencana_pm_2,
            'rencana_pm_3'=>$rencana_pm_3,
            'rencana_pm_4'=>$rencana_pm_4,
            'tgl_realisasi_pm_1'=>$tgl_realisasi_pm_1,
            'tgl_realisasi_pm_2'=>$tgl_realisasi_pm_2,
            'tgl_realisasi_pm_3'=>$tgl_realisasi_pm_3,
            'tgl_realisasi_pm_4'=>$tgl_realisasi_pm_4,
                );
                
            $result = $this->List_laporan_pm_model->editlist_laporan_pm_2($list_laporan_pmInfo, $id);
                
            redirect('list_laporan_pmListing');
            
        }
    }

    function formlist_laporan_pm()
    {
            $this->global['pageTitle'] = 'Monitoring SIMPANSE : Edit List_atm';
            
            $this->loadViews("formlist_laporan_pm", $this->global, NULL);
    }


    public function upload_list_laporan_pm()
    {
        // Load plugin PHPExcel nya
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';

        $config['upload_path'] = realpath('excel');
        $config['allowed_types'] = 'xlsx|xls|csv';
        $config['max_size'] = '1000000';
        $config['encrypt_name'] = true;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()) {

            //upload gagal
            $this->session->set_flashdata('notif', '<div class="alert alert-danger"><b>PROSES IMPORT GAGAL!</b> '.$this->upload->display_errors().'</div>');
            //redirect halaman
            redirect('import/');

        } else {

            $data_upload = $this->upload->data();

            $excelreader     = new PHPExcel_Reader_Excel2007();
            $loadexcel         = $excelreader->load('excel/'.$data_upload['file_name']); // Load file yang telah diupload ke folder excel
            $sheet             = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

            $data = array();

            $numrow = 1;
            foreach($sheet as $row){
                            if($numrow > 1){
                                array_push($data, array(
                                'id_atm' => $row['B'],
                                'wilayah' => $row['C'],
                                'lokasi' => $row['D'],
                                'cabang_pemilik' => $row['E'],
                                'alamat' => $row['F'],
                                'pengelola' => $row['G'],
                                'nama_pt_slm' => $row['H'],
                                'serial_mesin' => $row['I'],
                                'merk_atm' => $row['J'],
                                'tipe_atm' => $row['K'],
                                'tahun' => $row['L'],
                                'tanggal_aktivasi' => $row['M'],
                                'sla_part' => $row['N'],
                                'merk_cctv' => $row['O'],
                                'serial_number_cctv' => $row['P'],
                                'kondisi_kamera_cctv_dvr' => $row['Q'],
                                'merk_ups' => $row['R'],
                                'serial_number_ups' => $row['S'],
                                'kondisi_ups' => $row['T'],
                                'tegangan' => $row['U'],
                                'ground' => $row['V'],
                                'suhu_ruang' => $row['W'],
                                'status_merah_putih' => $row['X'],
                                'emv' => $row['Y'],
                                'mackey' => $row['Z'],
                                'whitelisting' => $row['AA'],
                                'agent_based' => $row['AB'],
                                'tapcash' => $row['AC'],
                                'enable_firewall' => $row['AD'],
                                'disable_smb' => $row['AE'],
                                'ip_address' => $row['AF'],
                                'jumlah_rencana' => $row['AG'],
                                'jumlah_realisasi' => $row['AH'],
                                'rencana_pm_1' => $row['AI'],
                                'rencana_pm_2' => $row['AJ'],
                                'rencana_pm_3' => $row['AK'],
                                'rencana_pm_4' => $row['AL'],
                                ));
                    }
                $numrow++;
            }
            $this->db->insert_batch('list_laporan_pm', $data);
            //delete file from server
            unlink(realpath('excel/'.$data_upload['file_name']));

            //upload success
            $this->session->set_flashdata('notif', '<div class="alert alert-success"><b>PROSES IMPORT BERHASIL!</b> Data berhasil diimport!</div>');
            //redirect halaman
            redirect('dashboard');

        }
    }
    function clearlist_laporan_pm()
    {
            $result = $this->List_laporan_pm_model->clearlist_laporan_pm();
            redirect('list_laporan_pmListing');
    }

    function deletelist_laporan_pm()
    {
            $id = $this->input->post('id');
            
            $result = $this->List_laporan_pm_model->deletelist_laporan_pm($id);
        redirect('list_laporan_pmListing');
    }

}

    
   