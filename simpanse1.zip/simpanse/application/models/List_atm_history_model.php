<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class List_atm_history_model extends CI_Model
{
    /**
     * This function is used to get the list_atm_history listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

    function list_atm_historyListingCount($id_atmText ='')
    {
    if($_SESSION['roleText'] == "ADMIN"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('status_selesai', 'APPROVED BY ATR');
        $query = $this->db->get();
        
        return count($query->result());
    }
    elseif($_SESSION['roleText'] == "FLM" || $_SESSION['roleText'] == "SLM"  ){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('name_yang_edit', $_SESSION['name']);  
        $this->db->where('tgl_selesai', '');
        $query = $this->db->get();
        
        return count($query->result());
    }
        elseif($_SESSION['roleText'] == "ATR"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah_asli', $_SESSION['name']);  


        $status_selesai = array('APPROVED BY ATR','ON PROSES');
        $this->db->where_in('status_selesai', $status_selesai);

        $query = $this->db->get();
        
        return count($query->result());
    }
    }
    
    /**
     * This function is used to get the list_atm_history listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function list_atm_historyListing($id_atmText ='', $page, $segment)
    {
    if($_SESSION['roleText'] == "ADMIN"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('status_selesai', 'APPROVED BY ATR');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    elseif($_SESSION['roleText'] == "FLM" || $_SESSION['roleText'] == "SLM"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('name_yang_edit', $_SESSION['name']);  
        $this->db->where('tgl_selesai', '');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    } 
    elseif($_SESSION['roleText'] == "ATR"){
        $this->db->select('BaseTbl.*');
        $this->db->from('list_atm_history as BaseTbl');
        if(!empty($id_atmText)) {
            $likeCriteria = "(BaseTbl.id_atm  LIKE '%".$id_atmText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('wilayah_asli', $_SESSION['name']);  


        $status_selesai = array('APPROVED BY ATR','ON PROSES');
        $this->db->where_in('status_selesai', $status_selesai);

        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    } 
    }

    function approved_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai)
    { 
        $this->db->set('tgl_selesai', $tgl_selesai);  
        $this->db->set('jam_selesai', $jam_selesai); 
        $this->db->set('status_selesai', $status_selesai);     
        $this->db->where('id_edit', $id_edit);
        $this->db->update('list_atm_history');
        
        return $this->db->affected_rows();
    }

      function rejected_status_selesai($id_edit, $tgl_selesai, $jam_selesai, $status_selesai,$ket_selesai)
    { 
        $this->db->set('tgl_selesai', $tgl_selesai);  
        $this->db->set('jam_selesai', $jam_selesai); 
        $this->db->set('status_selesai', $status_selesai);         
        $this->db->set('ket_selesai', $ket_selesai);     
        $this->db->where('id_edit', $id_edit);
        $this->db->update('list_atm_history');
        
        return $this->db->affected_rows();
    }


    function approved_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai)
    { 
        $this->db->set('tgl_selesai', $tgl_selesai);  
        $this->db->set('jam_selesai', $jam_selesai); 
        $this->db->set('status_selesai', $status_selesai);     
        $this->db->where('id_edit', $id_edit);
        $this->db->update('list_atm_history');
        
        return $this->db->affected_rows();
    }

      function rejected_status_atr($id_edit, $tgl_selesai, $jam_selesai, $status_selesai,$ket_selesai)
    { 
        $this->db->set('tgl_selesai', $tgl_selesai);  
        $this->db->set('jam_selesai', $jam_selesai); 
        $this->db->set('status_selesai', $status_selesai);         
        $this->db->set('ket_selesai', $ket_selesai);     
        $this->db->where('id_edit', $id_edit);
        $this->db->update('list_atm_history');
        
        return $this->db->affected_rows();
    }

    function update_id_atm($list_atmInfo, $id)
    { 
        $this->db->where('id', $id);
        $this->db->update('list_atm', $list_atmInfo);
        
        return TRUE;
    }
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
}

  